import numpy as np
import soundfile as sf
from scipy.signal import butter, lfilter

def butter_bandstop(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    # Sử dụng btype='bandstop' để triệt tiêu năng lượng trong dải tần mục tiêu
    b, a = butter(order, [low, high], btype='bandstop')
    return b, a

def attack():
    input_file = "stego_voice.wav"
    output_file = "stego_voice_filtered.wav"
    
    try:
        # 1. Đọc file stego đã tạo ở Bước 1
        data, fs = sf.read(input_file)
        print(f"[*] Dang tan cong file: {input_file}")
        
        # 2. Thiet lap thong so bo loc (2000Hz - 2500Hz)
        lowcut = 2000.0
        highcut = 2500.0
        
        # 3. Thuc hien loc de xoa du lieu tin giau
        b, a = butter_bandstop(lowcut, highcut, fs, order=9)
        filtered_data = lfilter(b, a, data)
        
        # 4. Luu file sau tan cong
        sf.write(output_file, filtered_data, fs)
        print(f"[+] Tan cong thanh cong! File ket qua: {output_file}")
        print(f"[!] Da quet sach nang luong trong dai tan 2000Hz - 2500Hz.")

    except Exception as e:
        print(f"[!] Loi: {e}")
        print("[-] Hay dam bao ban da chay xong buoc giau tin de co file stego_voice.wav")

if __name__ == "__main__":
    attack()
